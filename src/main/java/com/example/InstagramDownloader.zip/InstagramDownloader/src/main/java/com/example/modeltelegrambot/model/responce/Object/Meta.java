package com.example.modeltelegrambot.model.responce.Object;

import lombok.Data;

@Data
public class Meta{
	String source;
	String title;
}