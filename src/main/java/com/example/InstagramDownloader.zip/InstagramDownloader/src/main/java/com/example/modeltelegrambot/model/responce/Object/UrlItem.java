package com.example.modeltelegrambot.model.responce.Object;

import lombok.Data;

@Data
public class UrlItem{
	String ext;
	String name;
	String type;
	String url;
}