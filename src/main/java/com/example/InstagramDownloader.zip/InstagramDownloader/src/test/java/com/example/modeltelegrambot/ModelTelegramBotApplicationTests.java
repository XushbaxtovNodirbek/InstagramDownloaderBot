package com.example.modeltelegrambot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelTelegramBotApplicationTests {

    @Test
    void contextLoads() {
    }

}
